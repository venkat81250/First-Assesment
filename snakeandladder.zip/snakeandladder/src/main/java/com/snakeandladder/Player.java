package com.snakeandladder;

public class Player {
	
	private int playerId;
	private String playerName;
	private int playerPreviousPosition;
	private int playerCurrentPosition;
	private int playerNextPosition;
	private boolean isPlayerWinner;
	private boolean isPlayerTurn;
	private Square square;
	
	public Player() {
		super();
	}

	public Player(int playerId, String playerName, int playerPreviousPosition, int playerCurrentPosition,
			int playerNextPosition, boolean isPlayerWinner, boolean isPlayerTurn, Square square) {
		super();
		this.playerId = playerId;
		this.playerName = playerName;
		this.playerPreviousPosition = playerPreviousPosition;
		this.playerCurrentPosition = playerCurrentPosition;
		this.playerNextPosition = playerNextPosition;
		this.isPlayerWinner = isPlayerWinner;
		this.isPlayerTurn = isPlayerTurn;
		this.square = square;
	}

	public int getPlayerId() {
		return playerId;
	}

	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public int getPlayerPreviousPosition() {
		return playerPreviousPosition;
	}

	public void setPlayerPreviousPosition(int playerPreviousPosition) {
		this.playerPreviousPosition = playerPreviousPosition;
	}

	public int getPlayerCurrentPosition() {
		return playerCurrentPosition;
	}

	public void setPlayerCurrentPosition(int playerCurrentPosition) {
		this.playerCurrentPosition = playerCurrentPosition;
	}

	public int getPlayerNextPosition() {
		return playerNextPosition;
	}

	public void setPlayerNextPosition(int playerNextPosition) {
		this.playerNextPosition = playerNextPosition;
	}

	public boolean isPlayerWinner() {
		return isPlayerWinner;
	}

	public void setPlayerWinner(boolean isPlayerWinner) {
		this.isPlayerWinner = isPlayerWinner;
	}

	public boolean isPlayerTurn() {
		return isPlayerTurn;
	}

	public void setPlayerTurn(boolean isPlayerTurn) {
		this.isPlayerTurn = isPlayerTurn;
	}

	public Square getSquare() {
		return square;
	}

	public void setSquare(Square square) {
		this.square = square;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	
	
	
}
