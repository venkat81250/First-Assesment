package com.snakeandladder;

import java.util.Random;

public class DiceRollLogic {
	private final int MIN_VALUE =1;
	
	private Dice dice = new Dice();
	
	public Dice getDice() {
		return dice;
	}

	public void setDice(Dice dice) {
		this.dice = dice;
	}

	public DiceRollLogic(Dice dice) {
		super();
		this.dice = dice;
	}


	public DiceRollLogic() {
		super();
	}

	
	public int rollDice() {
	Random random = new Random();
	int randomNum = random.nextInt(dice.getNoOffaces()) + MIN_VALUE;
	System.out.println("Dice rolled:"+ randomNum);
	return randomNum;
	}
	
}
