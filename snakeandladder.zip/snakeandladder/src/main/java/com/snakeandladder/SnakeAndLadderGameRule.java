package com.snakeandladder;

import java.util.HashMap;
import java.util.Map;

public class SnakeAndLadderGameRule{
	
	private Map<Integer,Integer> snakeRuleMap = new HashMap<Integer,Integer>();
	private Map<Integer,Integer> ladderRuleMap = new HashMap<Integer,Integer>();
	
	
	public Map<Integer, Integer> getSnakeRuleMap() {
		return snakeRuleMap;
	}

	public void setSnakeRuleMap(Map<Integer, Integer> snakeRuleMap) {
		this.snakeRuleMap = snakeRuleMap;
	}

	public Map<Integer, Integer> getLadderRuleMap() {
		return ladderRuleMap;
	}

	public void setLadderRuleMap(Map<Integer, Integer> ladderRuleMap) {
		this.ladderRuleMap = ladderRuleMap;
	}

	
	public SnakeAndLadderGameRule() {
		super();
	}

	public SnakeAndLadderGameRule(Map<Integer, Integer> snakeRuleMap, Map<Integer, Integer> ladderRuleMap) {
		super();
		this.snakeRuleMap = snakeRuleMap;
		this.ladderRuleMap = ladderRuleMap;
	}

	public String addSnakeRule() {
		snakeRuleMap.put(92, 70);
		snakeRuleMap.put(97, 24);
		snakeRuleMap.put(86, 54);
		snakeRuleMap.put(62, 37);
		snakeRuleMap.put(55, 33);
		snakeRuleMap.put(47, 5);
		snakeRuleMap.put(38, 15);		
		snakeRuleMap.put(4, 2);
		snakeRuleMap.put(5, 1);
		return "Snake rule was added !";
	}
	
	public String addLadderRule() {
		ladderRuleMap.put(3, 6);
		ladderRuleMap.put(7, 10);
		ladderRuleMap.put(82, 100);
		ladderRuleMap.put(85, 95);
		ladderRuleMap.put(74, 88);
		ladderRuleMap.put(32, 68);
		ladderRuleMap.put(8, 34);
		return "Ladder rule was added !";
	}

}
