package com.snakeandladder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Board {

	private List<Dice> diceList = new ArrayList<Dice>();
	private List<Square> squaresList = new LinkedList<Square>();
	private List<Player> playerList = new ArrayList<Player>();

	private Map<Integer, Integer> snakeRuleMap = new HashMap<Integer, Integer>();
	private Map<Integer, Integer> ladderRuleMap = new HashMap<Integer, Integer>();

	public Board() {
		super();
	}

	public Board(List<Dice> diceList, List<Square> squaresList, List<Player> playerList,
			Map<Integer, Integer> snakeRuleMap, Map<Integer, Integer> ladderRuleMap) {
		super();
		this.diceList = diceList;
		this.squaresList = squaresList;
		this.playerList = playerList;
		this.snakeRuleMap = snakeRuleMap;
		this.ladderRuleMap = ladderRuleMap;
	}

	public List<Dice> getDiceList() {
		return diceList;
	}

	public void setDiceList(List<Dice> diceList) {
		this.diceList = diceList;
	}

	public List<Square> getSquaresList() {
		return squaresList;
	}

	public void setSquaresList(List<Square> squaresList) {
		this.squaresList = squaresList;
	}

	public List<Player> getPlayerList() {
		return playerList;
	}

	public void setPlayerList(List<Player> playerList) {
		this.playerList = playerList;
	}

	public Map<Integer, Integer> getSnakeRuleMap() {
		return snakeRuleMap;
	}

	public void setSnakeRuleMap(Map<Integer, Integer> snakeRuleMap) {
		this.snakeRuleMap = snakeRuleMap;
	}

	public Map<Integer, Integer> getLadderRuleMap() {
		return ladderRuleMap;
	}

	public void setLadderRuleMap(Map<Integer, Integer> ladderRuleMap) {
		this.ladderRuleMap = ladderRuleMap;
	}

	public String move(Player p, int s) {
		SnakeAndLadderGameRule rule = new SnakeAndLadderGameRule();
		Square sq = new Square();
		rule.addSnakeRule();
		rule.addLadderRule();
		snakeRuleMap = rule.getSnakeRuleMap();
		ladderRuleMap = rule.getLadderRuleMap();
		//System.out.println("Player" + p.getPlayerId()+ " takes a turn");
		System.out.println("Player" +p.getPlayerId()+ " is at Square:" + p.getPlayerCurrentPosition());
		p.setPlayerPreviousPosition(p.getPlayerCurrentPosition());
		p.setPlayerCurrentPosition(p.getPlayerCurrentPosition() + s);
		sq.setSquareNumber(p.getPlayerCurrentPosition());
		p.setSquare(sq);

		boolean isPlayerExceedsTheSquareLimitResponse = isPlayerExceedsTheSquareLimit(p); 
		if (isPlayerExceedsTheSquareLimitResponse) {
			System.out.println("Player" +p.getPlayerId()+ " lands on square"  + p.getPlayerCurrentPosition() 
		);

			// Snake rules:
			for (Map.Entry<Integer, Integer> rules : snakeRuleMap.entrySet()) {
				
				if (p.getPlayerCurrentPosition() == (Integer) rules.getKey()) {
					
					p.setPlayerPreviousPosition(p.getPlayerCurrentPosition());
					p.setPlayerCurrentPosition((Integer) rules.getValue());
					sq.setSquareNumber(p.getPlayerCurrentPosition());
					p.setSquare(sq);
					System.out.println("\n Snake! Player" + p.getPlayerId() + " goes from "
							+ p.getPlayerPreviousPosition() + " to " + p.getPlayerCurrentPosition()+"\n");
				}
			}

			// Ladder rules:
			for (Map.Entry<Integer, Integer> rules : ladderRuleMap.entrySet()) {
				
				// Applying the ladder rule:
				if (p.getPlayerCurrentPosition() == (Integer) rules.getKey()) {
					
					p.setPlayerPreviousPosition(p.getPlayerCurrentPosition());
					p.setPlayerCurrentPosition((Integer) rules.getValue());
					sq.setSquareNumber(p.getPlayerCurrentPosition());
					p.setSquare(sq);
					System.out.println("\n Ladder! Player" + p.getPlayerId() + " goes from "
							+ p.getPlayerPreviousPosition() + " to " + p.getPlayerCurrentPosition()+"\n");
				} else {
					
					p.setPlayerCurrentPosition(p.getPlayerCurrentPosition());
					sq.setSquareNumber(p.getPlayerCurrentPosition());
					p.setSquare(sq);
					

				}

			}

		}

		else {

			
			p.setPlayerCurrentPosition(p.getPlayerPreviousPosition());
			System.out.println("Player current position was :" + p.getPlayerCurrentPosition());
			sq.setSquareNumber(p.getPlayerPreviousPosition());
			return
				"Player squares were exceeded the limit so we are following the game rules";
		}

		if (p.getPlayerCurrentPosition() == squaresList.size()) {
			System.out.println("Player" + p.getPlayerId() + " won the game! ");
			System.exit(0);

		}

		return "Player" +p.getPlayerId()+ " was moved from " + p.getPlayerPreviousPosition() + "  to " + p.getPlayerCurrentPosition()+"\n"
				;
	}

	
	boolean isPlayerExceedsTheSquareLimit(Player p) {
		if ((p.getPlayerCurrentPosition() <= squaresList.size())
				|| (p.getSquare().getSquareNumber() <= squaresList.size())) {
			return true;
		} else
			return false;
	}

	boolean isPlayerWin(Player p) {
		if (p.getSquare().getSquareNumber() == squaresList.size()) {

			System.exit(0);
			return true;
		} else
			return false;

	}

	void game_Square_SetUp() {
		int noOfSquares = 100;
		for (int i = 1; i <= noOfSquares; i++) {
			Square addSquares = new Square(i);
			squaresList.add(addSquares);
		}
		System.out.println("Squares size :" + squaresList.size());
	}

	void noOfSquares() {
		for (Square sq : squaresList) {
			System.out.println(sq.getSquareNumber());
		}
	}

	void game_Dice_SetUp() {
		
		System.out.println("Enter the no of Dices required :");
		Scanner sc = new Scanner(System.in);
		int noOfDices = sc.nextInt();
		for (int i = 1; i <= noOfDices; i++) {
			Dice dc = new Dice();
			diceList.add(dc);
		}
		System.out.println("No of Dices in the game is " + diceList.size());
		sc.close();
	}

	void game_Player_SetUp() {
		int noOfPlayers =3;
		for (int i = 1; i <= noOfPlayers; i++) {
			Player playerObj = new Player();
			playerObj.setPlayerId(i);
			playerObj.setPlayerPreviousPosition(0);
			playerObj.setPlayerCurrentPosition(0);
			playerObj.setPlayerNextPosition(0);
			Square initialSquarePositiion = new Square(0);
			playerObj.setSquare(initialSquarePositiion);
			playerList.add(playerObj);
		}
		
	}

	String execute(Player p, int fromNumber, int toNumber) {
		Square s = new Square();
		if (s.getSquareNumber() == fromNumber) {
			p.setPlayerPreviousPosition(p.getPlayerCurrentPosition());
			p.setPlayerCurrentPosition(p.getPlayerCurrentPosition() - toNumber);
		}
		return "Snake Rules were applied !";
	}

}