package com.snakeandladder;

import java.util.*;

public class Game {

	private Board board = new Board();
	private Square square = new Square();
	private Player player = new Player();

	Scanner sc = new Scanner(System.in);

	public Game(Board board, Square square, Scanner sc) {
		super();
		this.board = board;
		this.square = square;
		this.sc = sc;
	}

	public Game() {
		super();
	}

	public static void main(String[] args) {

		Game game = new Game();
		
		game.board.game_Square_SetUp();
		
		
		game.board.game_Player_SetUp();
		
		

		if (game.board.getPlayerList().size() >= 0) {
			for (int playerTurn = 1; playerTurn <= game.board.getPlayerList().size(); playerTurn++) {
				Player p = game.board.getPlayerList().get(playerTurn - 1);
				
				System.out.println("Player" + p.getPlayerId() + " takes a turn");

				
				Dice dice = new Dice(6);
				DiceRollLogic diceRollLogic = new DiceRollLogic(dice);
				System.out.println(game.board.move(p, diceRollLogic.rollDice()));
				
				
				if (playerTurn >= game.board.getPlayerList().size()) {
					
					if (p.isPlayerWinner() == false) {
						playerTurn = 0;
					} else {
						System.out.println("Player" + p.getPlayerId() + " won the game: ");
						
						System.exit(0);
					}
				}
			}

		}
	}
}
