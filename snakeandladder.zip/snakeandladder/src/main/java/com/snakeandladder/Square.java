package com.snakeandladder;

public class Square {
	
	private int squareNumber;
	
	public int getSquareNumber() {
		return squareNumber;
	}

	public void setSquareNumber(int squareNumber) {
		this.squareNumber = squareNumber;
	}

	public Square() {
		super();
	}

	public Square(int squareNumber) {
		super();
		this.squareNumber = squareNumber;
	}
	


}
