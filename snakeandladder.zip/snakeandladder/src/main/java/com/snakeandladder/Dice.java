package com.snakeandladder;




public class Dice {
	
	private int NoOffaces;
	
	public Dice() {
		super();
	}

	public Dice(int noOffaces) {
		super();
		NoOffaces = noOffaces;
	}

	public int getNoOffaces() {
		return NoOffaces;
	}

	public void setNoOffaces(int noOffaces) {
		NoOffaces = noOffaces;
	}
	
	


}

